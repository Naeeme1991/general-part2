import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Login from "./forms/Login/Login";

class App extends Component {
  render() {

    return (

      <div className="App" style={{fontSize:'35px'}}>
        <Login/>
      </div>
    );
  }
}
export default App;
